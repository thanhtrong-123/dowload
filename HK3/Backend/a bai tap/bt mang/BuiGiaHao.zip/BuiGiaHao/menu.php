<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Menu</title>
    <style>
        table, td {
            border: 1px solid black;
            border-collapse : collapse;
        }
        td {
            width: 300px;
        }
    </style>
</head>
<body>
    <table>
        <tr>
            <td>
            <ul>
                Món khai vị:
                <br>
                <?php 
                    if (isset($_POST['khaivi'])) {
                        $selectedKhaiVi = $_POST['khaivi'];
                        foreach ($selectedKhaiVi as $khaiVi) { ?>
                            <li>
                                <?php echo $khaiVi; ?>
                            </li>
                        <?php }
                    } else {
                        echo "Chưa chọn món";
                    }
                ?>
                </ul>
            </td>
            <td>
            <ul>
                Món chính:
                <br>
                <?php 
                    if (isset($_POST['monchinh'])) {
                        $selectedMonChinh = $_POST['monchinh'];
                        foreach ($selectedMonChinh as $monChinh) { ?>
                            <li>
                                <?php echo $monChinh; ?>
                            </li>
                        <?php } 
                    } else {
                        echo "Chưa chọn món";
                    }
                ?>
                </ul>
            </td>
            <td>
                <ul>
                    Món tráng miệng:
                    <br>
                <?php 
                    if (isset($_POST['trangmieng'])) {
                        $selectedTrangMieng = $_POST['trangmieng'];
                        foreach ($selectedTrangMieng as $trangMieng) { ?>
                            <li>
                                <?php echo $trangMieng; ?>
                            </li>
                        <?php } 
                    } else {
                        echo "Chưa chọn món";
                    }
                ?>
                 </ul>
            </td>
        </tr>
    </table>
</body>
</html>
<?php 
  

