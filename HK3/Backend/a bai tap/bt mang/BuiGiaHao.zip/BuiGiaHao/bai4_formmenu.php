<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Menu</title>
</head>
<body>
    <h3>Menu</h3>
    <form action="menu.php" method="post">
    <label for="khaivi">Món Khai Vị:</label>
        <br>
            <select name="khaivi[]" id="khaivi" multiple size = 4> 
                <option value="Gỏi ngó sen">Gỏi ngó sen</option>
                <option value="Salat cá ngừ">Salat cá ngừ</option>
                <option value="Bò trộn rau thơm">Bò trộn rau thơm</option>
                <option value="Thịt nguội">Thịt nguội</option>
            </select>
            <br>
        <label for="monchinh">Món chính:</label>
        <br>
            <select name="monchinh[]" id="monchinh" multiple>
                <option value="Bò hầm">Bò hầm</option>
                <option value="Cá chẽm sốt cà">Cá chẽm sốt cà</option>
                <option value="Tôm rang muối">Tôm rang muối</option>
                <option value="Cua sốt me">Cua sốt me</option>
                <option value="Beefsteak">Golden Ramsay beefsteak but is "well-done"</option>
            </select>
            <br>
        <label for="trangmieng">Món tráng miệng:</label>
        <br>
            <select name="trangmieng[]" id="trangmieng" multiple>
                <option value="Chè hạt sen">Chè hạt sen</option>
                <option value="Bánh flan">Bánh flan</option>
                <option value="Rau câu">Rau câu</option>
            </select>
        <br>
        <br>
        <button type="submit">Submit</button>

    </form>
</body>
</html>