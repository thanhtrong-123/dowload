<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Info</title>
</head>
<body>
    <form action="" method="post">
        Name: <input type="text" name="name" require>
        <br>
        E-mail: <input type="email" name="email" require>
        <br>
        Website: <input type="text" name="website" require>
        <br>
        Comment: <textarea name="comment" id="" cols="30" rows="5" require></textarea>
        <br>
        Gender: 
        <input type="radio" id="female" name="gender" value="Female" require>
        <label for="female">Female</label>
        <input type="radio" id="male" name="gender" value="Male" require>
        <label for="male">Male</label>
        <br>
        <button type="submit">Submit</button>
    </form>
    <?php
        if (isset($_POST['name']) && isset($_POST['email']) && isset($_POST['website']) && isset($_POST['comment'])
        && isset($_POST['gender'])) {
            $name = $_POST['name'];
            $email = $_POST['email'];
            $website = $_POST['website'];
            $comment = $_POST['comment'];
            $gender = $_POST['gender'];
            $personInfo = array(
                'Name'=>$name,
                'E-mail'=>$email,
                'Website'=>$website,
                'Comment'=>$comment,
                'Gender'=>$gender
            ); 
            foreach ($personInfo as $key=>$value) {
                echo $key . ": " . $value . "<br>";
            }
        } else {
            echo "Chưa nhập đầy đủ thông tin.";
        }
    ?>
</body>
</html>