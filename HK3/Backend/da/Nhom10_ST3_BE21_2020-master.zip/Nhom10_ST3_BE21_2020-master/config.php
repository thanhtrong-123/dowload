<?php
/** The name of the database for WordPress */
define( 'DB_NAME', 'quochoang' );
/** MySQL database username */
define( 'DB_USER', 'root' );
/** MySQL database password */
define( 'DB_PASSWORD', '' );
/** MySQL hostname */
define( 'DB_HOST', 'localhost' );
/** port number of DB */
define( 'PORT', '3306');
/** Database Charset to use in creating database tables. */
define( 'DB_CHARSET', 'utf8' );
?>